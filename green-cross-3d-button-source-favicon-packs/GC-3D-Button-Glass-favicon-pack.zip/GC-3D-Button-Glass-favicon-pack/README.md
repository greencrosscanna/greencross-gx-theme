# Green Cross 3D Button Glass Favicon Pack

Source artwork: `GC_3D_Button_Glass.png`

Generated directly from the supplied 540x540 transparent PNG button artwork without changing the source design.

## Included

- `favicon.ico` - multi-size ICO with 16, 32, 48, 64, 128, and 256 px entries
- `favicon-16x16.png`
- `favicon-32x32.png`
- `apple-touch-icon.png` - 180x180
- `android-chrome-192x192.png`
- `android-chrome-512x512.png`
- `site.webmanifest`
- `png/` - additional PNG exports from 16 through 1024 px

## HTML example

```html
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
```
